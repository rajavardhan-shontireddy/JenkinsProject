import { LightningElement } from 'lwc';
 
export default class AccountLwc extends LightningElement {}