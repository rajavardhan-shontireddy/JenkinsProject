const mortgageCalc = function(){

    return 'hello world shared';
}
export default mortgageCalc;